package com.example.god.weatherlayout;

/**
 * Created by GOD on 13-05-2017.
 */

public class ip_address {

    public static String ip = "192.168.43.190";
}

