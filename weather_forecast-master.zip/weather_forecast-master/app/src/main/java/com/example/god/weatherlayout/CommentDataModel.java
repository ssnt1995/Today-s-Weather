package com.example.god.weatherlayout;

public class CommentDataModel {

    public String comment , email , name ;




    public CommentDataModel()
    {

    }
}
