package com.example.god.weatherlayout;

public class locationDataModel {

    public String location , location_id;

    public locationDataModel()
    {

    }
}
