package com.example.god.weatherlayout;

public class Images_data_model {


    public String image , description , location;

    public String image_id;


    public Images_data_model()
    {

    }

}
