package com.example.god.weatherlayout;

class createaccount {
    public String name,email,loc;

    createaccount()
    {

    }

    public createaccount(String name, String email,String loc)

    {
        this.name = name;
        this.email=email;
        this.loc=loc;


    }

}
