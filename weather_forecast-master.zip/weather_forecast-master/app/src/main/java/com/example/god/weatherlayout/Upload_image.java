package com.example.god.weatherlayout;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class Upload_image extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_upload_image);
    }
}
